# Dokumen Desain Awal — Klasifikasi Sendok vs Garpu

**Computer Vision and Deep Learning:** RE503  **Nama:** [Crystiade Eka Syahputra Tarigan]


## 1. Latar belakang & tujuan
Sistem visi sederhana yang membedakan **sendok** dan **garpu** dari citra, sebagai studi kasus
transfer learning pada dataset kecil. Tujuan: membandingkan 3 mode pelatihan dan memilih model
yang akurat sekaligus cepat saat inferensi.

## 2. Use case
[ISI: contoh penerapan, mis. penyortiran alat makan otomatis / robot pengambil alat makan.]

## 3. Kelas & dataset
| Kelas | Definisi | Jumlah citra |
|---|---|---|
| fork | Garpu (berbagai jenis & sudut pandang) | 199 |
| spoon | Sendok (berbagai jenis & sudut pandang) | 151 |

- Sumber data: dataset *spoon-vs-fork* (`archive.zip`) — [ISI: URL sumber & lisensi]
- Total 350 citra (syarat ≥ 50/kelas terpenuhi); format JPEG 320, PNG 28, WEBP 2
- Resolusi: fork 180–1000 px, spoon 224–500 px (median 500 px) → di-resize ke 224×224
- Disimpan di `dataset_raw/<kelas>/`, dicatat di `metadata.csv`
- Pembersihan: salinan folder bersarang yang identik dibuang; semua file terbaca; tidak ada duplikat persis
- Pembagian data: 70% train / 15% validation / 15% test, stratified per kelas, seed 42
  (train 244 · validation 53 · test 53)

## 4. Pipeline
1. `make_metadata.py` — validasi gambar, catat metadata, tentukan split
2. Preprocessing — resize 224×224, augmentasi (flip, rotasi 0.2, zoom 0.2) **hanya pada train**
3. Model — EfficientNetB0 + GlobalAveragePooling2D + Dropout(0.3) + Dense(1, sigmoid)
4. Training — Adam, binary crossentropy, EarlyStopping (patience 5, monitor val_loss)
5. Evaluasi — akurasi & loss pada test set, grafik akurasi per epoch
6. Latensi — forward pass batch=1 pada model terpilih

## 5. Tiga mode eksperimen
| Mode | Bobot awal | Layer yang dilatih | Learning rate |
|---|---|---|---|
| Scratch | acak | seluruh model | 1e-3 |
| Feature extraction | ImageNet | hanya head | 1e-3 |
| Fine-tuning | ImageNet | head (fase 1), lalu 30 layer teratas (fase 2) | 1e-3 → 1e-5 |

## 6. Metrik keberhasilan
- Akurasi validasi/test per mode (utama)
- Stabilitas kurva train vs validation (indikasi overfitting)
- Latensi inferensi rata-rata dan P95 (ms), ukuran model (MB)
- Pemilihan model berdasarkan **validasi**, test set hanya untuk pelaporan akhir

## 7. Risiko & mitigasi
| Risiko | Mitigasi |
|---|---|
| Dataset kecil (350 citra) → overfitting | Augmentasi, dropout, early stopping, transfer learning |
| Validation/test kecil (53 citra) → metrik kasar | Laporkan jumlah sampel, tambah macro-F1 & confusion matrix |
| Kelas agak tidak seimbang (57% : 43%) | Laporkan macro-F1 selain akurasi |
| Kebocoran data (gambar mirip di split berbeda) | Sudah dicek: tidak ada duplikat persis, 2 pasangan near-duplicate dicatat sebagai keterbatasan |
| Gambar didominasi latar putih / foto produk | Augmentasi; catat sebagai keterbatasan generalisasi |


