"""Melatih EfficientNetB0 dalam 3 mode:

  scratch             : arsitektur sama, bobot acak (tanpa pretrained)
  feature_extraction  : bobot ImageNet, backbone dibekukan, hanya head dilatih
  fine_tuning         : fase 1 melatih head, fase 2 membuka N layer teratas (lr kecil)

Contoh:  python src/train.py --mode feature_extraction
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import tensorflow as tf
from PIL import Image
from tensorflow.keras import layers, models
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.callbacks import EarlyStopping

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"
IMG_SIZE = (224, 224)
SEED = 42
MODES = ["scratch", "feature_extraction", "fine_tuning"]
KEYS = ["accuracy", "loss", "val_accuracy", "val_loss"]


def load_arrays(df, split, classes):
    """Baca gambar dengan PIL (berdasarkan isi file, aman untuk .php/.ashx/.webp)."""
    d = df[df["split"] == split]
    cmap = {c: i for i, c in enumerate(classes)}
    X = []
    for p in d["filepath"]:
        with Image.open(ROOT / p) as im:
            X.append(np.asarray(im.convert("RGB").resize(IMG_SIZE, Image.BILINEAR), dtype=np.float32))
    y = d["label"].map(cmap).astype("float32").to_numpy().reshape(-1, 1)
    return np.stack(X), y


def make_ds(X, y, batch, training):
    ds = tf.data.Dataset.from_tensor_slices((X, y))
    if training:
        ds = ds.shuffle(len(X), seed=SEED)
    ds = ds.batch(batch)
    if training:  # augmentasi hanya untuk data training
        aug = tf.keras.Sequential([
            layers.RandomFlip("horizontal_and_vertical"),
            layers.RandomRotation(0.2),
            layers.RandomZoom(0.2),
        ])
        ds = ds.map(lambda a, b: (aug(a, training=True), b), num_parallel_calls=tf.data.AUTOTUNE)
    return ds.prefetch(tf.data.AUTOTUNE)


def build_model(mode):
    weights = None if mode == "scratch" else "imagenet"
    base = EfficientNetB0(include_top=False, weights=weights, input_shape=(*IMG_SIZE, 3))
    base.trainable = mode == "scratch"
    model = models.Sequential([
        base,
        layers.GlobalAveragePooling2D(),
        layers.Dropout(0.3),
        layers.Dense(1, activation="sigmoid"),
    ])
    return model, base


def compile_model(model, lr):
    model.compile(optimizer=tf.keras.optimizers.Adam(lr),
                  loss="binary_crossentropy", metrics=["accuracy"])


def unfreeze_top(base, n):
    base.trainable = True
    for layer in base.layers[:-n]:
        layer.trainable = False
    for layer in base.layers[-n:]:
        if isinstance(layer, layers.BatchNormalization):
            layer.trainable = False  # BN tetap beku agar stabil


def fit(model, train_ds, val_ds, epochs, patience):
    es = EarlyStopping(monitor="val_loss", patience=patience, restore_best_weights=True)
    return model.fit(train_ds, validation_data=val_ds, epochs=epochs,
                     callbacks=[es], verbose=2).history


def class_report(true, pred, n_classes):
    cm = np.zeros((n_classes, n_classes), dtype=int)
    for t, p in zip(true, pred):
        cm[t, p] += 1
    rep = []
    for i in range(n_classes):
        tp = cm[i, i]
        prec = tp / cm[:, i].sum() if cm[:, i].sum() else 0.0
        rec = tp / cm[i, :].sum() if cm[i, :].sum() else 0.0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
        rep.append({"precision": float(prec), "recall": float(rec), "f1": float(f1),
                    "support": int(cm[i, :].sum())})
    return cm, rep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=MODES)
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--patience", type=int, default=5)
    ap.add_argument("--head_epochs", type=int, default=5, help="fine_tuning: epoch fase 1")
    ap.add_argument("--unfreeze", type=int, default=30, help="fine_tuning: jumlah layer dibuka")
    a = ap.parse_args()

    tf.keras.utils.set_random_seed(SEED)
    df = pd.read_csv(ROOT / "metadata.csv")
    classes = sorted(df["label"].unique())
    Xtr, ytr = load_arrays(df, "train", classes)
    Xva, yva = load_arrays(df, "validation", classes)
    Xte, yte = load_arrays(df, "test", classes)
    train_ds = make_ds(Xtr, ytr, a.batch, True)
    val_ds = make_ds(Xva, yva, a.batch, False)
    test_ds = make_ds(Xte, yte, a.batch, False)

    model, base = build_model(a.mode)
    phase2_start = None
    t0 = time.time()

    if a.mode == "fine_tuning":
        compile_model(model, 1e-3)
        h1 = fit(model, train_ds, val_ds, a.head_epochs, a.patience)
        unfreeze_top(base, a.unfreeze)
        compile_model(model, 1e-5)
        h2 = fit(model, train_ds, val_ds, max(a.epochs - a.head_epochs, 1), a.patience)
        history = {k: [float(v) for v in h1[k] + h2[k]] for k in KEYS}
        phase2_start = len(h1["loss"]) + 1
    else:
        compile_model(model, 1e-3)
        h = fit(model, train_ds, val_ds, a.epochs, a.patience)
        history = {k: [float(v) for v in h[k]] for k in KEYS}

    train_time = time.time() - t0
    test_loss, test_acc = model.evaluate(test_ds, verbose=0)

    prob = model.predict(Xte, batch_size=a.batch, verbose=0).ravel()
    pred = (prob >= 0.5).astype(int)
    cm, rep = class_report(yte.ravel().astype(int), pred, len(classes))

    metrics = {
        "mode": a.mode,
        "classes": classes,
        "epochs_run": len(history["loss"]),
        "best_val_accuracy": max(history["val_accuracy"]),
        "best_val_loss": min(history["val_loss"]),
        "test_accuracy": float(test_acc),
        "test_loss": float(test_loss),
        "test_macro_f1": float(np.mean([r["f1"] for r in rep])),
        "per_class": dict(zip(classes, rep)),
        "confusion_matrix": cm.tolist(),  # baris = label asli, kolom = prediksi
        "trainable_params": int(sum(np.prod(w.shape) for w in model.trainable_weights)),
        "total_params": int(model.count_params()),
        "train_time_s": round(train_time, 1),
        "phase2_start_epoch": phase2_start,
        "n_train": len(Xtr),
        "n_val": len(Xva),
        "n_test": len(Xte),
    }

    RES.mkdir(exist_ok=True)
    (ROOT / "models").mkdir(exist_ok=True)
    (RES / f"history_{a.mode}.json").write_text(json.dumps(history, indent=2))
    (RES / f"metrics_{a.mode}.json").write_text(json.dumps(metrics, indent=2))
    model.save(ROOT / "models" / f"{a.mode}.keras")

    print("\n=== HASIL", a.mode, "===")
    print(f"Test accuracy : {test_acc * 100:.2f}%  (loss {test_loss:.4f})")
    print(f"Test macro-F1 : {metrics['test_macro_f1'] * 100:.2f}%")
    print(f"Best val acc  : {metrics['best_val_accuracy'] * 100:.2f}%")


if __name__ == "__main__":
    main()
