"""Membuat grafik akurasi per epoch, confusion matrix, dan tabel hasil 3 mode dari results/."""
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"
MODES = ["scratch", "feature_extraction", "fine_tuning"]
NAMES = {
    "scratch": "Scratch (tanpa pretrained)",
    "feature_extraction": "Feature extraction",
    "fine_tuning": "Fine-tuning",
}


def main():
    data = {}
    for m in MODES:
        hp, mp = RES / f"history_{m}.json", RES / f"metrics_{m}.json"
        if hp.exists() and mp.exists():
            data[m] = (json.loads(hp.read_text()), json.loads(mp.read_text()))
    if not data:
        raise SystemExit("Belum ada hasil. Jalankan src/train.py dulu.")

    # 1) Akurasi train vs val per epoch, satu panel per mode
    fig, axes = plt.subplots(1, len(data), figsize=(5 * len(data), 4), sharey=True, squeeze=False)
    for ax, (m, (h, mt)) in zip(axes[0], data.items()):
        ep = range(1, len(h["accuracy"]) + 1)
        ax.plot(ep, h["accuracy"], label="Train")
        ax.plot(ep, h["val_accuracy"], label="Validation")
        if mt.get("phase2_start_epoch"):
            ax.axvline(mt["phase2_start_epoch"] - 0.5, ls="--", c="gray", label="Mulai unfreeze")
        ax.set_title(NAMES[m])
        ax.set_xlabel("Epoch")
        ax.grid(True)
        ax.legend()
    axes[0][0].set_ylabel("Akurasi")
    fig.tight_layout()
    fig.savefig(RES / "accuracy_per_epoch.png", dpi=150)
    plt.close(fig)

    # 2) Perbandingan akurasi validasi antar mode
    plt.figure(figsize=(7, 4.5))
    for m, (h, _) in data.items():
        plt.plot(range(1, len(h["val_accuracy"]) + 1), h["val_accuracy"], label=NAMES[m])
    plt.title("Perbandingan Akurasi Validasi per Epoch")
    plt.xlabel("Epoch")
    plt.ylabel("Validation accuracy")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(RES / "accuracy_val_comparison.png", dpi=150)
    plt.close()

    # 3) Confusion matrix (test set) tiap mode
    fig, axes = plt.subplots(1, len(data), figsize=(4.5 * len(data), 4), squeeze=False)
    for ax, (m, (_, mt)) in zip(axes[0], data.items()):
        cm, cls = mt["confusion_matrix"], mt["classes"]
        ax.imshow(cm, cmap="Blues")
        for i in range(len(cls)):
            for j in range(len(cls)):
                ax.text(j, i, cm[i][j], ha="center", va="center",
                        color="white" if cm[i][j] > max(map(max, cm)) / 2 else "black")
        ax.set_xticks(range(len(cls)), cls)
        ax.set_yticks(range(len(cls)), cls)
        ax.set_xlabel("Prediksi")
        ax.set_ylabel("Label asli")
        ax.set_title(NAMES[m])
    fig.tight_layout()
    fig.savefig(RES / "confusion_matrices.png", dpi=150)
    plt.close(fig)

    # 4) Tabel hasil
    # Model dipilih berdasarkan VALIDASI (bukan test): val acc tertinggi, seri -> val loss terendah.
    selected = max(data, key=lambda m: (data[m][1]["best_val_accuracy"], -data[m][1]["best_val_loss"]))
    lines = [
        "| Mode | Epoch | Best val acc | Best val loss | Test acc | Test macro-F1 | Test loss | Param trainable | Waktu training (s) |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for m, (_, mt) in data.items():
        star = " ⭐" if m == selected else ""
        lines.append(
            f"| {NAMES[m]}{star} | {mt['epochs_run']} | {mt['best_val_accuracy']*100:.2f}% | "
            f"{mt['best_val_loss']:.4f} | {mt['test_accuracy']*100:.2f}% | {mt['test_macro_f1']*100:.2f}% | "
            f"{mt['test_loss']:.4f} | {mt['trainable_params']:,} | {mt['train_time_s']} |"
        )
    lines.append("")
    lines.append(f"⭐ = model terpilih (`{selected}`), dipilih dari akurasi validasi.")
    (RES / "results_table.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (RES / "selected_mode.txt").write_text(selected)

    print("\n".join(lines))
    print("\nTersimpan: results/accuracy_per_epoch.png, accuracy_val_comparison.png, "
          "confusion_matrices.png, results_table.md")


if __name__ == "__main__":
    main()
