"""Membuat metadata.csv dari dataset_raw/<kelas>/*.

Kolom: filepath, label, split, format, width, height, size_kb
- Format file dideteksi dari ISI file (bukan ekstensi), karena beberapa file
  di dataset punya ekstensi .php/.ashx padahal isinya JPEG.
- Split dibuat stratified per kelas dengan seed tetap (default 70/15/15),
  sehingga train.py selalu memakai pembagian yang sama dan bisa direproduksi.
"""
import argparse
import csv
import os
import random
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
MIN_PER_CLASS = 50


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default=str(ROOT / "dataset_raw"))
    ap.add_argument("--out", default=str(ROOT / "metadata.csv"))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--val", type=float, default=0.15)
    ap.add_argument("--test", type=float, default=0.15)
    a = ap.parse_args()

    raw = Path(a.raw)
    classes = sorted(d.name for d in raw.iterdir() if d.is_dir())
    if not classes:
        raise SystemExit(f"Tidak ada folder kelas di {raw}")

    rng = random.Random(a.seed)
    rows = []
    for cls in classes:
        good = []
        for p in sorted((raw / cls).iterdir()):
            if not p.is_file() or p.name.startswith("."):
                continue
            try:
                with Image.open(p) as im:
                    im.verify()
                with Image.open(p) as im:
                    fmt, (w, h) = im.format, im.size
                good.append((p, fmt, w, h))
            except Exception as e:  # bukan gambar / rusak
                print(f"[SKIP] {p} ({e})")

        rng.shuffle(good)
        n = len(good)
        n_test = round(n * a.test)
        n_val = round(n * a.val)
        for i, (p, fmt, w, h) in enumerate(good):
            if i < n_test:
                split = "test"
            elif i < n_test + n_val:
                split = "validation"
            else:
                split = "train"
            rows.append({
                "filepath": Path(os.path.relpath(p, ROOT)).as_posix(),
                "label": cls,
                "split": split,
                "format": fmt,
                "width": w,
                "height": h,
                "size_kb": round(p.stat().st_size / 1024, 1),
            })

        flag = "" if n >= MIN_PER_CLASS else f"  <-- KURANG dari {MIN_PER_CLASS}!"
        print(f"{cls}: total={n}{flag}")

    rows.sort(key=lambda r: r["filepath"])
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), lineterminator="\n")
        w.writeheader()
        w.writerows(rows)

    print(f"\nmetadata.csv ditulis: {a.out} ({len(rows)} baris)")
    for split in ("train", "validation", "test"):
        per = {c: sum(1 for r in rows if r["split"] == split and r["label"] == c) for c in classes}
        print(f"  {split:<10}: {per}")


if __name__ == "__main__":
    main()
