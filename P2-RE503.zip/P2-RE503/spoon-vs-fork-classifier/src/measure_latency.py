"""Mengukur latensi inferensi (batch=1) model terpilih.

Contoh:  python src/measure_latency.py            # pakai results/selected_mode.txt
         python src/measure_latency.py --mode fine_tuning
Catatan: yang diukur hanya forward pass model (tanpa baca file / resize).
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import tensorflow as tf

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default=None)
    ap.add_argument("--runs", type=int, default=100)
    ap.add_argument("--warmup", type=int, default=20)
    a = ap.parse_args()

    mode = a.mode or (RES / "selected_mode.txt").read_text().strip()
    path = ROOT / "models" / f"{mode}.keras"
    model = tf.keras.models.load_model(path)

    x = tf.constant(np.random.randint(0, 256, (1, 224, 224, 3)).astype("float32"))
    for _ in range(a.warmup):
        model(x, training=False).numpy()

    times = []
    for _ in range(a.runs):
        t = time.perf_counter()
        model(x, training=False).numpy()  # .numpy() memastikan eksekusi selesai
        times.append((time.perf_counter() - t) * 1000)

    info = {
        "mode": mode,
        "device": "GPU" if tf.config.list_physical_devices("GPU") else "CPU",
        "batch_size": 1,
        "input_size": [224, 224, 3],
        "runs": a.runs,
        "mean_ms": round(float(np.mean(times)), 2),
        "median_ms": round(float(np.median(times)), 2),
        "p95_ms": round(float(np.percentile(times, 95)), 2),
        "min_ms": round(float(np.min(times)), 2),
        "max_ms": round(float(np.max(times)), 2),
        "fps": round(1000 / float(np.mean(times)), 1),
        "model_size_mb": round(path.stat().st_size / 1024 / 1024, 2),
    }
    (RES / "latency.json").write_text(json.dumps(info, indent=2))
    md = (
        "| Model | Device | Mean (ms) | Median (ms) | P95 (ms) | FPS | Ukuran model (MB) |\n"
        "|---|---|---|---|---|---|---|\n"
        f"| {mode} | {info['device']} | {info['mean_ms']} | {info['median_ms']} | "
        f"{info['p95_ms']} | {info['fps']} | {info['model_size_mb']} |\n"
    )
    (RES / "latency.md").write_text(md, encoding="utf-8")
    print(md)


if __name__ == "__main__":
    main()
